<?php

require_once('../vendor/autoload.php');

date_default_timezone_set(TIME_ZONE);

new \App\Core\Core();